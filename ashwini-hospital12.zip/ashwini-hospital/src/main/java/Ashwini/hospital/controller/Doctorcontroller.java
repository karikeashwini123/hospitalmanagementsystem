package Ashwini.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Ashwini.hospital.DTO.DoctorDTO;
import Ashwini.hospital.DTO.DoctorSaveDTO;
import Ashwini.hospital.DTO.DoctorUpdateDTO;
import Ashwini.hospital.entity.Doctor;
import Ashwini.hospital.service.DoctorInterface;
import Ashwini.hospital.service.DoctorServiceIMPL;

@RestController //It is used for sending the data.
@CrossOrigin  
@RequestMapping("api/v1/doctor")
public class Doctorcontroller {
	
	@Autowired
	private DoctorInterface doctorService;
	 
    @PostMapping(path = "/save")
 
    public String saveDoctor(@RequestBody DoctorSaveDTO doctorSaveDTO)
    {
        String id = doctorService.addDoctor(doctorSaveDTO);
        return id;
    }
 
    @GetMapping(path = "/getAllDoctor")
    public List<DoctorDTO> getAllDoctor()
    {
       List<DoctorDTO>allDoctor = doctorService.getAllDoctor();
       return allDoctor;
    }
 
    @PutMapping(path = "/update")
 
    public String updateDoctor(@RequestBody DoctorUpdateDTO doctorUpdateDTO)
    {
        String id = doctorService.updateDoctors(doctorUpdateDTO);
        return id;
    }
 
    @DeleteMapping(path = "/deletedoctor/{id}")
    public String deleteDoctor(@PathVariable(value = "id") int id)
    {
        boolean deletestudent = doctorService.deleteDoctor(id);
        return "deleted";
    }
}
	
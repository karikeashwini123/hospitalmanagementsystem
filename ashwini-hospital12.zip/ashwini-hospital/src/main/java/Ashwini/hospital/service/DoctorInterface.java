package Ashwini.hospital.service;

import java.util.List;

import Ashwini.hospital.DTO.DoctorDTO;
import Ashwini.hospital.DTO.DoctorSaveDTO;
import Ashwini.hospital.DTO.DoctorUpdateDTO;



public interface DoctorInterface {
	String addDoctor(DoctorSaveDTO DoctorSaveDTO);
	List<DoctorDTO>getAllDoctor();
	String updateDoctors(DoctorUpdateDTO DoctorUpdateDTO);
	boolean deleteDoctor(int id);
	}


package Ashwini.hospital.service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import Ashwini.hospital.DTO.DoctorDTO;
import Ashwini.hospital.DTO.DoctorSaveDTO;
import Ashwini.hospital.DTO.DoctorUpdateDTO;
import Ashwini.hospital.entity.Doctor;
import Ashwini.hospital.repository.Doctorrepository;


@Service
public abstract class DoctorServiceIMPL implements DoctorInterface{

@Autowired
private Doctorrepository  doctorRepo;
 
@Override
public String addDoctor( DoctorSaveDTO  doctorSaveDTO)
{
	Doctor doctor= new Doctor(

			doctorSaveDTO.getDoctorFname(),
			doctorSaveDTO.getDoctoraddress(),
			doctorSaveDTO.getMobile(),
			doctorSaveDTO.getDesignation()


			
    );
	doctorRepo.save(doctor);
    return doctor.getDoctorFname();
}

@Override
public List<DoctorDTO> getAllDoctor() {
   List<Doctor> getDoctor = doctorRepo.findAll();
   List<DoctorDTO> doctorDTOList = new ArrayList<>();
   for(Doctor a:getDoctor)
   {
	   DoctorDTO doctorDTO = new DoctorDTO(

               a.getDoctorid(),
               a.getDoctorFname(),
               a.getDoctoraddress(),
               a.getDesignation(),
               a.getMobile()
              
                          );
       doctorDTOList.add(doctorDTO);
   }

   return  doctorDTOList;
}

@Override
public String updateDoctors(DoctorUpdateDTO doctorUpdateDTO)
{
    if (doctorRepo.existsById(doctorUpdateDTO.getDoctorid())) {
    	Doctor doctor =doctorRepo.getById(doctorUpdateDTO.getDoctorid());


    	doctor.setDoctorFname(doctorUpdateDTO.getDoctorFname());
    	doctor.setDoctoraddress(doctorUpdateDTO.getDoctoraddress());
    	doctor.setDesignation(doctorUpdateDTO.getDesignation());
    	doctor.setMobile(doctorUpdateDTO.getMobile());
    	
        doctorRepo.save(doctor);
    }
        else
        {
            System.out.println("Doctor ID do not Exist");
        }

            return null;
    }

@Override
public boolean deleteDoctor(int id) {

    if(doctorRepo.existsById(id))
    {
     doctorRepo.deleteById(id);
    }
    else
    {
        System.out.println("doctors id not found");
    }
    return true;
}
}
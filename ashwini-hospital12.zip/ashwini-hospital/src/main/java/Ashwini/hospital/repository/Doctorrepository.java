package Ashwini.hospital.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import Ashwini.hospital.entity.Doctor;


@EnableJpaRepositories
@Repository
public interface Doctorrepository extends JpaRepository<Doctor,Integer>{

}

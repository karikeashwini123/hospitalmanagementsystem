package Ashwini.hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AshwiniHospitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(AshwiniHospitalApplication.class, args);
	}

}

package Ashwini.hospital.DTO;

public class DoctorSaveDTO {
	
	private String DoctorFname;
	private String Doctoraddress;
	private int mobile;
	private String Designation;
	public DoctorSaveDTO( String Doctorname, String Doctoraddress, int mobile,String Designaton) {
		
		
		this.DoctorFname = DoctorFname;
		this.Doctoraddress = Doctoraddress;
		this.Designation = Designation;
		this.mobile = mobile;
	}
	public DoctorSaveDTO() 
	{
		
	}
	
	public String getDoctorFname() {
		return DoctorFname;
	}
	public void setDoctorFname(String DoctorFname) {
		this.DoctorFname = DoctorFname;
	}
	public String getDoctoraddress() {
		return Doctoraddress;
	}
	public void setDoctoraddress(String Doctoraddress) {
		this.Doctoraddress = Doctoraddress;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String Designation) {
		this.Designation = Designation;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "DoctorSaveDTO [DoctorFname=" + DoctorFname + ", Doctoraddress=" + Doctoraddress + ", mobile=" + mobile
				+ ", Designation=" + Designation + "]";
	}
}




package Ashwini.hospital.DTO;

public class DoctorDTO {
	private int Doctorid;
	private String DoctorFname;
	private String Doctoraddress;
	
	private String Designation;
	private int mobile;
	
	public DoctorDTO(int doctorid, String doctorFname, String doctoraddress, String designation, int mobile) {
		super();
		this.Doctorid = doctorid;
		this.DoctorFname = doctorFname;
		this.Doctoraddress = doctoraddress;
		this.Designation = designation;
		this.mobile = mobile;
	}

	public DoctorDTO() 
	{
		
	}
	
	
	
	public int getDoctorid() {
		return Doctorid;
	}

	public void setDoctorid(int doctorid) {
		Doctorid = doctorid;
	}

	public String getDoctorFname() {
		return DoctorFname;
	}

	public void setDoctorFname(String doctorFname) {
		DoctorFname = doctorFname;
	}

	public String getDoctoraddress() {
		return Doctoraddress;
	}

	public void setDoctoraddress(String doctoraddress) {
		Doctoraddress = doctoraddress;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "DoctorDTO [Doctorid=" + Doctorid + ", DoctorFname=" + DoctorFname + ", Doctoraddress=" + Doctoraddress
				+ ", Designation=" + Designation + ", mobile=" + mobile + "]";
	}

	

	}

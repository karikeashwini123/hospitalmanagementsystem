package Ashwini.hospital.DTO;

public class DoctorUpdateDTO {
	private int Doctorid;
	private String DoctorFname;
	private String Doctoraddress;
	private int mobile;
	private String Designation;
	public DoctorUpdateDTO(int Doctorid, String DoctorFname, String Doctoraddress, int mobile,String Designaton) {
		
		this.Doctorid = Doctorid;
		this.DoctorFname = DoctorFname;
		this.Doctoraddress = Doctoraddress;
		this.Designation = Designation;
		this.mobile = mobile;
	}
	public DoctorUpdateDTO() 
	{
		
	}
	public int getDoctorid() {
		return Doctorid;
	}
	public void setDoctorid(int Doctorid) {
		this.Doctorid = Doctorid;
	}
	public String getDoctorFname() {
		return DoctorFname;
	}
	public void setDoctorname(String DoctorFname) {
		this.DoctorFname = DoctorFname;
	}
	public String getDoctoraddress() {
		return Doctoraddress;
	}
	public void setDoctoraddress(String Doctoraddress) {
		this.Doctoraddress = Doctoraddress;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String Designation) {
		this.Designation = Designation;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "DoctorDTO [Doctorid=" + Doctorid + ",DoctorFname=" + DoctorFname + ", Doctoraddress="
				+ Doctoraddress + ", Designation=" +Designation + ", mobile=" + mobile + "]";
	}
	

	}


package Ashwini.hospital.entity;
import javax.persistence.*;

import javax.persistence.Column;
import lombok.Data;


@Entity
@Table(name="doctor")
@Data

public class Doctor {
	@Id
	@Column(name="Doctor_id",length=50)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int Doctorid;
	@Column(name="Doctor_Fname",length=50)
	private String DoctorFname;
	@Column(name="Doctor_address",length=100)
	private String Doctoraddress;
	@Column(name="Doctor_mobile",length=12)
	private int mobile;
	@Column(name="Doctor_Designation",length=10)
	private String Designation;
	


	public Doctor(int Doctorid, String Doctorname, String Doctoraddress, int mobile) {
		
		this.Doctorid = Doctorid;
		this.DoctorFname = DoctorFname;
		this.Doctoraddress = Doctoraddress;
		this.mobile = mobile;
		this.Designation = Designation;
	}
	public Doctor() {	
	}

	public Doctor(String doctorFname, String doctoraddress, int mobile, String Designation) {
		
		this.DoctorFname = doctorFname;
		this.Doctoraddress = doctoraddress;
		this.mobile = mobile;
		this.Designation = Designation;
		
	}
	public int getDoctorid() {
		return Doctorid;
	}
	public void setDoctorid(int Doctorid) {
		this.Doctorid = Doctorid;
	}
	public String getDoctorFname() {
		return DoctorFname;
	}
	public void setDoctorFname(String DoctorFname) {
		this.DoctorFname =DoctorFname;
	}
	public String getDoctoraddress() {
		return Doctoraddress;
	}
	public void setDoctoraddress(String Doctoraddress) {
		this.Doctoraddress = Doctoraddress;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String Designation) {
		this.Designation = Designation;
	}
	@Override
	public String toString() {
		return "Doctor [Doctorid=" + Doctorid + ", DoctorFname=" + DoctorFname + ", Doctoraddress=" + Doctoraddress
				+ ", mobile=" + mobile + ", Designation=" + Designation + "]";
	}

}
package Ashwini.hospital.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Patient {
	@Id
	@Column(name="Patient_id",length=50)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int Patientid;
	@Column(name="Patient_Fname",length=50)
	private String PatientFname;
	@Column(name="Patient_address",length=100)
	private String Patientaddress;
	@Column(name="Patient_mobile",length=12)
	private int mobile;
	
	@Column(name="patient_bloodgroup",length=5)
	private int patientbloodgroup;
	@Column(name="patient_gender",length=5)
	private String patientgender;

	public Patient(int Patientid, String Patientname, String Patientaddress, int mobile, String patientgender) {
		super();
		this.Patientid = Patientid;
		this.PatientFname = PatientFname;
		this.Patientaddress = Patientaddress;
		this.patientbloodgroup = patientbloodgroup;
		this.mobile = mobile;
		this.patientgender = patientgender;
	}
	public Patient() {	
	}

	public int getpatientid() {
		return Patientid;
	}
	public void setpatientid(int patientid) {
		this.Patientid = Patientid;
	}
	public String getpatientFname() {
		return PatientFname;
	}
	public void setpatientname(String patientFname) {
		this.PatientFname =PatientFname;
	}
	public String getpatientaddress() {
		return Patientaddress;
	}
	public void setpatientaddress(String patientaddress) {
		this.Patientaddress = Patientaddress;
	}
	public int getPatientbloodgroup() {
		return getPatientbloodgroup();
	}
	public void setPatientbloodgroup(int Patientbloodgroup) {
		this.patientbloodgroup = Patientbloodgroup;
	}
	public int mobile() {
		return mobile();
	}
	public void setmobile(int mobile) {
		this.mobile = mobile;
	}
	

	@Override
	public String toString() {
		return "Patient [Patientid=" +Patientid + ",PatientFname=" +PatientFname + ",Patientaddress="
				+ Patientaddress + ", mobile=" + mobile + ",patientbloodgroup="+ patientbloodgroup +",patientgender="+patientgender+"]";
	}
	}



